print("Teste com Banco de Dados Mysql")
print("Teste com Banco de Dados Mysql")
print("Exemplo")
import MySQLdb
con = MySQLdb.connect(db="casadb", user="root", passwd="[suasenha]", host="192.168.1.211")

cur = con.cursor()
sql = "select * from security"
cur.execute(sql)
recset = cur.fetchall()
for registro in recset: print(registro)